import { Document } from 'mongoose';

export type User = {
    email: string | null;
    password: string;
};

export interface UserDocument extends Document {
    email: string | null;
    password: string;
}
