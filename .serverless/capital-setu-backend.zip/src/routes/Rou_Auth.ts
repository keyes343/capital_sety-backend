import express, { Router, Request, Response, NextFunction } from 'express';
import mongoose, { Schema, model, Model, Document } from 'mongoose';
import { t } from './incoming';
import jwt from 'jsonwebtoken';
import bycrypt from 'bcrypt';

export class Auth {
    model_auth: Model<t.auth.AuthDocument>;
    model_user: Model<t.user.UserDocument>;
    router: Router;
    secret: string;
    constructor(Auth: Model<t.auth.AuthDocument>, user: Model<t.user.UserDocument>) {
        this.secret = 'lemonisgood';
        this.model_auth = Auth;
        this.model_user = user;
        this.router = express.Router();
        this.initialize();
    }

    private success = (res: Response, payload: any) => {
        res.status(200).send(payload);
    };
    private failed = (res: Response, msg: string) => {
        res.status(400).send(msg);
    };

    private authenticate = (req: Request, res: Response) => {
        const token_new = req.headers['x-access-token'] as string | undefined;
        if (!token_new) {
            this.failed(res, 'no token found');
            return;
        }
        const decoded = jwt.verify(token_new, this.secret);
        if (decoded) {
            console.log({
                decoded,
            });
        } else {
            res.status(401).send('Login expired');
        }
    };

    private initialize = () => {
        this.router.post('/login/:action', async (req: Request<{ action: 'getToken' | 'verify' }, {}, { username: string; password: string; token?: string }>, res: Response) => {
            const {
                body: { username, password },
                params: { action },
            } = req;
            console.log({ username, password, action });
            console.log({
                header: req.headers,
            });
            if (action === 'getToken' && (!username || !password)) {
                console.log('Failed ----');
                res.status(400).send({
                    msg: 'payload is missing username or password for /new',
                });
            }

            const token = jwt.sign({ username, password }, this.secret, {
                expiresIn: 86400,
            });
            console.log({ token });

            try {
                this.success(res, {
                    msg: 'token generated',
                    token,
                });
            } catch (error) {
                console.log({ error });
            }
        });

        this.router.post('/save', this.authenticate, async (req: Request<{}, {}, {}>, res: Response) => {});
    };
}
